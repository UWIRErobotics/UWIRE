
extern unsigned int adc_buf[16];

void adc_init();

void adc_start();

void adc_stop();

/* If needed this macro can be replaced by a function */
#define adc_read(pin) adc_buf[pin]
