/***********************************************************************
 *                                                                     *
 * This file contains the implementation of gyro.h                     *
 *                                                                     *
 ***********************************************************************
 *                                                                     * 
 *    Author:         Tom Pycke                                        *
 *    Filename:       gyro.c                                           *
 *    Date:           13/10/2007                                       *
 *    File Version:   1.00                                             *
 *    Other Files Required: gyro.h                                     *
 *                          adc.h                                      *
 *                                                                     *
 ***********************************************************************
 *                                                                     *
 * Other Comments:                                                     *
 *  It basically does the conversion from 16 bit raw value into a      *
 *  float representing radians per second                              *
 *                                                                     *
 ***********************************************************************/
 
 
#include "gyro.h"

#include "adc.h"

#define ROLL_ADC  0
#define PITCH_ADC 1 

static const float gyro_pitch_degrees_per_second = 500.0*2.0;
static const float gyro_roll_degrees_per_second = 500.0*2.0;

static const float gyro_pitch_rad_per_second = 8.72*2.0;
static const float gyro_roll_rad_per_second = 8.72*2.0;



/*
 *  Returns degrees per second along the roll axis
 *
 *    - Our gyro (IDG-300) is non-radiometric, meaning we should
 *      treat our measurements as if the device was running on 3V
 *      and not 3V3.
 *    - Centre (0�/s) is at 1.5V
 *    - 2mV per �/s (
 */
float gyro_roll_degrees()
{
	return -(((float)adc_read(ROLL_ADC) / 65500.0*3.3)-1.5)/0.002; 
}
float gyro_roll_rad()
{
	//return (((float)adc_read(ROLL_ADC) / 65500.0*3.3)-1.5)/0.002/180.0*3.14159;
	return -(((float)adc_read(ROLL_ADC) * 0.0004394279)-13.09);
}



/*
 *  Returns degrees per second along the pitch axis
 */
float gyro_pitch_degrees()
{
	return (((float)adc_read(PITCH_ADC) / 65500.0*3.3)-1.5)/0.002; 
	//return (float) ((int)adc_read(PITCH_ADC)-ADC_PITCH_NEUTRAL) * (gyro_pitch_degrees_per_second / 32750.0);
}
	
float gyro_pitch_rad()
{
	return (((float)adc_read(PITCH_ADC) * 0.0004394279)-13.09);
	//return (float) ((int)adc_read(PITCH_ADC)-ADC_PITCH_NEUTRAL) * (gyro_pitch_rad_per_second / 32750.0);
}
