

/* Initialzes the timer */
void timer_init_ms();

/* Resets the timer's counter */
void timer_reset();

/* Returns the time in seconds since the last call of this function (or last reset) */
float timer_dt();
