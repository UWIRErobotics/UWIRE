/***********************************************************************
 *                                                                     *
 * This file contains the implementation of accelero.h                 *
 *                                                                     *
 ***********************************************************************
 *                                                                     * 
 *    Author:         Tom Pycke                                        *
 *    Filename:       accelero.c                                       *
 *    Date:           13/10/2007                                       *
 *    File Version:   1.00                                             *
 *    Other Files Required: accelero.h                                 *
 *                          adc.h                                      *
 *                                                                     *
 ***********************************************************************
 *                                                                     *
 * Other Comments:                                                     *
 *  It basically does the conversion from 16 bit raw value into a      *
 *  float representing radians per second                              *
 *                                                                     *
 ***********************************************************************/
 
 
#include <math.h>

#include "gyro.h"

#include "adc.h"


static const int ADC_X_NEUTRAL = 33400;
static const int ADC_Y_NEUTRAL = 32900;
static const int ADC_Z_NEUTRAL = 32800;

#define ACCEL_Z_ADC 3
#define ACCEL_Y_ADC 4
#define ACCEL_X_ADC 5


// this axis should be towards the nose of the plane
float accelero_x()
{
	return (float)((long)adc_read(ACCEL_X_ADC) - 33000) / (39600.0-33000.0);
}

// this axis should be towards the right wingtip
float accelero_y()
{
	return (float)((long)adc_read(ACCEL_Y_ADC) - 32800) / (39400.0-32800.0);
}

// this axis should be towards the ground
float accelero_z()
{
	return (float)((long)adc_read(ACCEL_Z_ADC) - 32300) / (32300.0-25980.0);
}


unsigned int accelero_x_raw()
{
	return (unsigned int)adc_read(ACCEL_X_ADC);
}

unsigned int accelero_y_raw()
{
	return (unsigned int)adc_read(ACCEL_Y_ADC);
}

unsigned int accelero_z_raw()
{
	return (unsigned int)adc_read(ACCEL_Z_ADC);
}

float accelero_roll_radians()
{
	int shifted_z = (int)adc_read(ACCEL_Z_ADC) - ADC_Z_NEUTRAL;
	int shifted_y = (int)adc_read(ACCEL_Y_ADC) - ADC_Y_NEUTRAL;
	
	// no need to scale
	float z = (float) shifted_z;
	float y = (float) shifted_y;
	
	return -(atan2(-z, y)-(3.14159/2.0));
}


float accelero_pitch_radians()
{
	int shifted_z = (int)adc_read(ACCEL_Z_ADC) - ADC_Z_NEUTRAL;
	int shifted_x = (int)adc_read(ACCEL_X_ADC) - ADC_X_NEUTRAL;
	
	// no need to scale
	float z = (float) shifted_z;
	float x = (float) shifted_x;
	
	return atan2(-z, x);
}


float accelero_roll_degrees()
{
	
}


float accelero_pitch_degrees()
{
	
}
