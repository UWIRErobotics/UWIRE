/***********************************************************************
 *                                                                     *
 * This file contains dsPic30F3011 specifics that are being used       *
 * by all the device-depended files.                                   *
 *                                                                     *
 ***********************************************************************
 *                                                                     * 
 *    Author:         Tom Pycke                                        *
 *    Filename:       common.h                                         *
 *    Date:           13/10/2007                                       *
 *    File Version:   1.00                                             *
 *                                                                     *
 ***********************************************************************/
 

#include <p30f3011.h>

// we're using the internal oscillator so it's running at 7.37MHz
#define	FOSC	7372800
#define	PLL	    1
#define	FCY	    FOSC*PLL/4

