/***********************************************************************
 *                                                                     *
 * This file contains the implementation of uart1.h for the            *
 * dsPIC30F3011 device.                                                *
 *                                                                     *
 ***********************************************************************
 *                                                                     * 
 *    Author:         Tom Pycke                                        *
 *    Filename:       uart1.c                                          *
 *    Date:           13/10/2007                                       *
 *    File Version:   1.00                                             *
 *    Other Files Required: uart1.h                                    *
 *                                                                     *
 ***********************************************************************/

#include "common.h"
#include "../uart1.h"

#include <uart.h>

#define BAUDRATE 9600   //38400
#define UXBRG    FCY/16/BAUDRATE -1


void uart1_close()
{
	/* Turn off UART1module */
    CloseUART1();
}


void uart1_open()
{
	/* Holds the value of baud register   */
	unsigned int baudvalue;   
	
	/* Holds the value of uart config reg */
	unsigned int U1MODEvalue;

	/* Holds the information regarding uart
	   TX & RX interrupt modes */   
	unsigned int U1STAvalue; 

	uart1_close();
	
	/* Configure uart1 receive and transmit interrupt */
    ConfigIntUART1(UART_RX_INT_DIS & UART_TX_INT_DIS);

	/* Configure UART1 module to transmit 8 bit data with one stopbit. Also Enable loopback mode  */
    baudvalue = UXBRG;

    U1MODEvalue = UART_EN & UART_IDLE_CON & UART_ALTRX_ALTTX &
                  UART_DIS_WAKE & UART_DIS_LOOPBACK  &
                  UART_EN_ABAUD & UART_NO_PAR_8BIT  &
                  UART_1STOPBIT;

    U1STAvalue  = UART_INT_TX_BUF_EMPTY  &  
                  UART_TX_PIN_NORMAL &
                  UART_TX_ENABLE & UART_INT_RX_3_4_FUL &
                  UART_ADR_DETECT_DIS &
                  UART_RX_OVERRUN_CLEAR;
                  
	OpenUART1(U1MODEvalue, U1STAvalue, baudvalue);

	/* Load transmit buffer and transmit the same till null character is encountered */
	TRISFbits.TRISF6 = 0;
    
	PORTFbits.RF6 = 0;
}


void uart1_puts(char string[])
{
	putsUART1 ((unsigned int *)string);
	while (BusyUART1());
}
