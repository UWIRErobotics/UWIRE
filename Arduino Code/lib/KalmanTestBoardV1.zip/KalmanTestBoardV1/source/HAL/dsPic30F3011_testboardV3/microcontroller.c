/***********************************************************************
 *                                                                     *
 * This file contains dsPIC30F3011 specific code                       *
 *                                                                     *
 ***********************************************************************
 *                                                                     * 
 *    Author:         Tom Pycke                                        *
 *    Filename:       microcontroller.c                                *
 *    Date:           13/10/2007                                       *
 *    File Version:   1.00                                             *
 *    Other Files Required: microcontroller.h                          *
 *                                                                     *
 ***********************************************************************/
 
 
#include "common.h"


// configuration bits
_FWDT(WDT_OFF);                  //Turn off the Watch-Dog Timer.
_FBORPOR(MCLR_EN & PWRT_OFF);    //Enable MCLR reset pin and turn off the
                                 //power-up timers.
_FGS(CODE_PROT_OFF);             //Disable Code Protection

void init_microcontroller()
{
	
}
