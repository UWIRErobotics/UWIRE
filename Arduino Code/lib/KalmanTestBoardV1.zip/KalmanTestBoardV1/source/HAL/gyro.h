

/*
 *  Returns degrees per second along the pitch axis
 */
float gyro_pitch_degrees();


/*
 *  Returns degrees per second along the roll axis
 */
float gyro_roll_degrees();


/*
 *  Returns radians per second along the pitch axis
 */
float gyro_pitch_rad();


/*
 *  Returns radians per second along the roll axis
 */
float gyro_roll_rad();
