

void uart1_open();

void uart1_close();

// Sends a \0 terminated string to uart1
void uart1_puts(char[]);

