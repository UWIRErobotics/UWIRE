
void init_microcontroller();
